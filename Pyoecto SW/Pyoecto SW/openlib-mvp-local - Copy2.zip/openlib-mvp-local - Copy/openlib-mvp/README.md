# OpenLib Market MVP

Sistema de Gestión de Activos Digitales Académicos

## Requisitos

- **Java 21** (JDK)
- **Maven 3.9+**

> ✅ **Sin backend. Sin Docker. Sin base de datos.**
> Todo se guarda en archivos JSON dentro de la carpeta `data/` que se crea automáticamente.

## Cómo ejecutar

### Linux / Mac
```bash
chmod +x run.sh
./run.sh
```

### Windows
```bat
run.bat
```

El script compila y lanza directamente el cliente JavaFX. No hay backend que arrancar.

## Usuarios de prueba (cargados automáticamente al primer inicio)

| Rol    | Email                 | Contraseña   |
|--------|-----------------------|--------------|
| Admin  | admin@openlib.com     | Admin1234!   |
| Seller | seller@openlib.com    | Seller1234!  |
| Buyer  | buyer@openlib.com     | Buyer1234!   |

## ¿Dónde se guardan los datos?

En la carpeta `data/` (se crea al lado del JAR o desde donde ejecutes):

```
data/
  users.json       — usuarios registrados
  books.json       — catálogo de libros
  categories.json  — categorías
  cart.json        — carritos por usuario
  orders.json      — historial de órdenes
  library.json     — biblioteca personal
  wishlist.json    — listas de favoritos
  reviews.json     — reseñas
```

## ¿Quiero empezar desde cero?

Solo borra la carpeta `data/` y vuelve a ejecutar — los datos demo se recrean solos.

## Arquitectura

```
openlib-mvp/
├── openlib-backend/    # (no se usa — mantenido como referencia)
└── openlib-javafx/     # App de escritorio con persistencia en archivos JSON
    └── src/main/java/com/openlib/fx/
        ├── service/
        │   ├── LocalDataService.java  ← toda la lógica de datos (archivos JSON)
        │   └── ApiClient.java         ← router que llama a LocalDataService
        └── controller/                ← pantallas (sin cambios)
```
