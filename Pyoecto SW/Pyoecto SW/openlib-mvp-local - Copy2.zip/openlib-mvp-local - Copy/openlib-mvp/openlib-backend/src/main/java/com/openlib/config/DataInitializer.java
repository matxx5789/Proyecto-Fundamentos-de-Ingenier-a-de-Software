package com.openlib.config;

import com.openlib.domain.*;
import com.openlib.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Set;

/**
 * Inicializa datos de demo en la base de datos H2 al arrancar la aplicación.
 * Reemplaza el seed SQL de Flyway (V2) para garantizar que los hashes BCrypt
 * sean generados correctamente por el PasswordEncoder de Spring Security.
 *
 * Usuarios demo:
 *   admin@openlib.com  / Admin1234!   (ADMIN)
 *   seller@openlib.com / Seller1234!  (SELLER)
 *   buyer@openlib.com  / Buyer1234!   (BUYER)
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements ApplicationRunner {

    private final UserRepository     userRepository;
    private final CategoryRepository categoryRepository;
    private final TagRepository      tagRepository;
    private final BookRepository     bookRepository;
    private final PasswordEncoder    passwordEncoder;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (userRepository.count() > 0) {
            log.info("DataInitializer: datos ya presentes, omitiendo seed.");
            return;
        }

        log.info("DataInitializer: inicializando datos de demo...");

        // ── Usuarios ──────────────────────────────────────────────────────────
        User admin = userRepository.save(User.builder()
                .email("admin@openlib.com")
                .username("admin")
                .passwordHash(passwordEncoder.encode("Admin1234!"))
                .fullName("Administrador OpenLib")
                .role(Role.ADMIN)
                .isActive(true)
                .isVerified(true)
                .build());

        User seller = userRepository.save(User.builder()
                .email("seller@openlib.com")
                .username("demo_seller")
                .passwordHash(passwordEncoder.encode("Seller1234!"))
                .fullName("Seller Demo")
                .role(Role.SELLER)
                .isActive(true)
                .isVerified(true)
                .build());

        userRepository.save(User.builder()
                .email("buyer@openlib.com")
                .username("demo_buyer")
                .passwordHash(passwordEncoder.encode("Buyer1234!"))
                .fullName("Buyer Demo")
                .role(Role.BUYER)
                .isActive(true)
                .isVerified(true)
                .build());

        log.info("DataInitializer: usuarios creados: {}, {}, buyer@openlib.com",
                admin.getEmail(), seller.getEmail());

        // ── Categorías ────────────────────────────────────────────────────────
        Category catProg = saveCategory("Programación",        "programacion",        "Libros sobre lenguajes, algoritmos y patrones de diseño");
        Category catData = saveCategory("Ciencias de Datos",   "ciencias-de-datos",   "Machine learning, estadística y análisis de datos");
        Category catMath = saveCategory("Matemáticas",         "matematicas",          "Álgebra, cálculo, estadística y matemática discreta");
                           saveCategory("Ingeniería",          "ingenieria",           "Libros de ingeniería de software y sistemas");
                           saveCategory("Bases de Datos",      "bases-de-datos",       "SQL, NoSQL, modelado y administración de BD");
                           saveCategory("Redes y Seguridad",   "redes-y-seguridad",    "Redes de computadoras, ciberseguridad y criptografía");
                           saveCategory("Sistemas Operativos", "sistemas-operativos",  "Linux, Windows, kernels y administración de sistemas");

        // ── Etiquetas ─────────────────────────────────────────────────────────
        Tag tagJava    = saveTag("Java",        "java");
        Tag tagPython  = saveTag("Python",      "python");
        Tag tagJs      = saveTag("JavaScript",  "javascript");
        Tag tagSpring  = saveTag("Spring",      "spring");
        Tag tagSql     = saveTag("SQL",         "sql");
        Tag tagNoSql   = saveTag("NoSQL",       "nosql");
        Tag tagDocker  = saveTag("Docker",      "docker");
        Tag tagGit     = saveTag("Git",         "git");
        Tag tagOpen    = saveTag("Open Source", "open-source");
        Tag tagFree    = saveTag("Gratuito",    "gratuito");
        Tag tagAcad    = saveTag("Académico",   "academico");

        // ── Libros de muestra ─────────────────────────────────────────────────
        saveBook("Clean Code: A Handbook of Agile Software Craftsmanship",
                "Robert C. Martin", "9780132350884",
                "Guía definitiva para escribir código limpio, mantenible y profesional.",
                "en", 2008, catProg, seller,
                new BigDecimal("0.00"), 4.80, 42,
                Set.of(tagJava, tagOpen, tagAcad));

        saveBook("Designing Data-Intensive Applications",
                "Martin Kleppmann", "9781491903124",
                "El libro definitivo para entender sistemas distribuidos, bases de datos y arquitecturas modernas de datos.",
                "en", 2017, catData, seller,
                new BigDecimal("0.00"), 4.90, 78,
                Set.of(tagNoSql, tagSql, tagDocker, tagAcad));

        saveBook("Spring Boot en Acción",
                "Craig Walls", "9781617292545",
                "Aprende a construir aplicaciones Spring Boot desde cero hasta producción.",
                "es", 2022, catProg, seller,
                new BigDecimal("0.00"), 4.70, 35,
                Set.of(tagJava, tagSpring, tagDocker));

        saveBook("The Pragmatic Programmer",
                "David Thomas, Andrew Hunt", "9780135957059",
                "Tu viaje hacia la maestría en el desarrollo de software.",
                "en", 2019, catProg, seller,
                new BigDecimal("0.00"), 4.85, 91,
                Set.of(tagOpen, tagGit, tagAcad));

        saveBook("Introduction to Algorithms",
                "Thomas H. Cormen", "9780262033848",
                "El libro de referencia más completo sobre algoritmos y estructuras de datos.",
                "en", 2022, catMath, seller,
                new BigDecimal("0.00"), 4.60, 120,
                Set.of(tagAcad, tagFree));

        log.info("DataInitializer: seed completado exitosamente.");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Category saveCategory(String name, String slug, String description) {
        if (categoryRepository.existsByName(name)) return categoryRepository.findBySlug(slug).orElseThrow();
        return categoryRepository.save(Category.builder()
                .name(name).slug(slug).description(description).build());
    }

    private Tag saveTag(String name, String slug) {
        if (tagRepository.existsByName(name)) return tagRepository.findBySlug(slug).orElseThrow();
        return tagRepository.save(Tag.builder().name(name).slug(slug).build());
    }

    private void saveBook(String title, String author, String isbn, String description,
                          String language, int year, Category category, User seller,
                          BigDecimal price, double rating, int reviewCount, Set<Tag> tags) {
        Book book = Book.builder()
                .title(title)
                .author(author)
                .isbn(isbn)
                .description(description)
                .language(language)
                .publishedYear(year)
                .price(price)
                .status(BookStatus.APPROVED)
                .category(category)
                .seller(seller)
                .averageRating(new BigDecimal(String.valueOf(rating)))
                .reviewCount(reviewCount)
                .downloadCount(0L)
                .tags(tags)
                .build();
        bookRepository.save(book);
    }
}
